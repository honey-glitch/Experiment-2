## Introduction (Round 0)

Remove this line before submitting : To Refer a filled sample of this template visit here : <br> http://vlabs.iitb.ac.in/gitlab/Community-Docs/New-Lab-development/Samples
<br>

<b>Discipline | <b>Type Name of Discpline  to which lab belongs
:--|:--|
<b> Lab | <b> Type name of the lab
<b> Experiment|     <b> 1. (enter the correct experiment number) Name of the experiment

<h5> About the Lab (Objective) : </h5>

Type here: berif description of the lab

<h5> About the Experiment : </h5>

Type here: berif description of this experiment

<h5> Target Audience : </h5>

Type here: the target audience

<h5> Course Alignment : </h5>

Type here: courses aligned

<h5> Universities Mapped : </h5>

Type here: universities mapped

<b>Name of Developer | <b> (of professor only (no prefix Prof/Mr/MRS) - - - - - -
:--|:--|
<b> Institute | <b> My Institute name
<b> Email id|     <b> abc@example.com
<b> Department | Name of the department in which you work

#### Mentor Details

<b>Mentored by | <b> (of professor only (no prefix Prof/Mr/MRS) - - - - - -
:--|:--|
<b> Institute | <b> Institute name
<b> Email id|     <b> abc@example.com
<b> Department | Name of the department

#### Contributors List

SrNo | Name | Faculty or Student | Department| Institute | Email id
:--|:--|:--|:--|:--|:--|
1 | Full name | Faculty | Dept Name | Name of the Insitute, City | abc@example.com
2 | Full name | Student | Dept Name | Name of the Insitute, City |abc@example.com
3 | Full name | Student | Dept Name | Name of the Insitute, City |abc@example.com
4 | Full name | Student | Dept Name | Name of the Insitute, City |abc@example.com


<br>
for more details on Rounds visit : <b> [HERE](http://vlabs.iitb.ac.in/gitlab/Community-Docs/New-Lab-development/List-of-Rounds/blob/master/README.md) </b>
