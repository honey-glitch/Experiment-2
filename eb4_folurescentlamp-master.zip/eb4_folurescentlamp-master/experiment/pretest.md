## <b> Pre-test
#### Please attempt the following questions

1) Interference occurs due to _______ of the light.<br>
<b>a) Wave nature<br></b>
b) particle nature<br>
c) both a and b<br>
d) none of these<br>

2) Superposition of crest over crest results in __________ .<br>
a) Destructive interference<br>
<b> b) Constructive interference<br></b>
c) Diffraction<br>
d) Polarization<br>

3) If two waves with amplitude (y1) and (y2) travelling in the same medium reach at a point in the medium, then the resultant displacement at that point in the medium, will be given by __________ .<br>
a) y1 -y2<br>
<b>b) y1 + y2<br></b>
c) y1 / y2<br>
d) y1 * y2<br>

4) The condition for destructive interference is: the path difference should be equal to __________. <br>
<b>a) Odd integral multiple of wavelength<br></b>
b) Integral multiple of wavelength<br>
c) Odd integral multiple of half wavelength<br>
d) Integral multiple of half wavelength<br>

5) In Newton's ring experiment, the diameter of the dark rings is proportional to __________ .<br>
a) Odd natural numbers<br>
b) Even natural numbers<br>
c) Complex numbers<br>
<b>d) square root of natural numbers<br></b>
