## Post test
<br>
Q 1. What will happen, if the glass plate is replaced with plane mirror?<br>
<b>a. There will be no interference fringe<br></b>
b. There will be interference fringe<br>
c. colored fringes will be observed<br>
d. None of the options<br><br>

Q 2. What will happen, if sodium light is replaced with white light?<br>
a. There will be no interference fringe<br>
b. There will be interference fringe<br>
<b>c. colored fringes will be observed<br></b>
d. No change in pattern is visible<br>

Q 3. What will appear, if in place of lens, a plane glass making some angle with the glass stripe  is used?<br>
<b>a. Alternate dark and bright fringes in shape of a straight line.<br></b>
b. triangular interference pattern<br>
c. colored fringes will be observed<br>
d. No change in pattern is visible<br>

Q 4. Colours observed in thin film are because of ________________<br>
a. Diffraction<br>
<b>b. Interference<br></b>
c. Polarization<br>
d. None of the options<br>

Q 5.  In Newton’s rings experiment, rings are formed when the light is ________________ by
lower surface of the lens and upper surface of the glass plate, interfere.<br>
a. Reflected<br>
<b>b. Refracted<br></b>
c. Transmitted<br>
d. None<br></b>
